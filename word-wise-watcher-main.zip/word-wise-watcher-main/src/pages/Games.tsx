import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import AppLayout from '@/components/AppLayout';
import { Brain, BookOpen, Eye, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';

const gameCards = [
  { id: 'memory', icon: Brain, colorClass: 'from-[hsl(199,89%,48%)] to-[hsl(199,89%,38%)]', titleKey: 'memoryRecall', descKey: 'memoryDesc' },
  { id: 'word', icon: BookOpen, colorClass: 'from-[hsl(262,60%,55%)] to-[hsl(262,60%,45%)]', titleKey: 'wordRecall', descKey: 'wordDesc' },
  { id: 'spot', icon: Eye, colorClass: 'from-[hsl(38,90%,55%)] to-[hsl(38,90%,45%)]', titleKey: 'spotDifference', descKey: 'spotDesc' },
  { id: 'attention', icon: Target, colorClass: 'from-[hsl(340,70%,55%)] to-[hsl(340,70%,45%)]', titleKey: 'attentionFocus', descKey: 'attentionDesc' },
];

const Games = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-heading font-bold text-foreground mb-2">{t('games')}</h1>
        <p className="text-muted-foreground mb-8">{t('tagline')}</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {gameCards.map((game, i) => (
            <div
              key={game.id}
              className="bg-card rounded-2xl shadow-card border border-border overflow-hidden hover:shadow-elevated transition-all duration-300 animate-fade-in group cursor-pointer"
              style={{ animationDelay: `${i * 100}ms` }}
              onClick={() => navigate(`/game/${game.id}`)}
            >
              <div className={`h-32 bg-gradient-to-br ${game.colorClass} flex items-center justify-center group-hover:scale-105 transition-transform`}>
                <game.icon className="w-14 h-14 text-primary-foreground opacity-90" />
              </div>
              <div className="p-5">
                <h3 className="font-heading font-semibold text-lg text-foreground mb-1">{t(game.titleKey)}</h3>
                <p className="text-muted-foreground text-sm mb-4">{t(game.descKey)}</p>
                <Button variant="outline" className="w-full">{t('startGame')}</Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

export default Games;
