import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import AppLayout from '@/components/AppLayout';
import MemoryGame from '@/components/games/MemoryGame';
import WordRecallGame from '@/components/games/WordRecallGame';
import SpotDifferenceGame from '@/components/games/SpotDifferenceGame';
import AttentionGame from '@/components/games/AttentionGame';
import { useLanguage } from '@/contexts/LanguageContext';

const GamePlay = () => {
  const { gameId } = useParams<{ gameId: string }>();
  const navigate = useNavigate();
  const { t } = useLanguage();

  const renderGame = () => {
    switch (gameId) {
      case 'memory': return <MemoryGame />;
      case 'word': return <WordRecallGame />;
      case 'spot': return <SpotDifferenceGame />;
      case 'attention': return <AttentionGame />;
      default: return <div>Game not found</div>;
    }
  };

  return (
    <AppLayout>
      <button onClick={() => navigate('/games')} className="text-sm text-primary hover:underline mb-4 inline-block">
        ← {t('backToGames')}
      </button>
      {renderGame()}
    </AppLayout>
  );
};

export default GamePlay;
