import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import AppLayout from '@/components/AppLayout';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Trophy, Flame, Star, Target, Brain, BookOpen, Eye } from 'lucide-react';

const COLORS = ['hsl(199,89%,48%)', 'hsl(152,60%,45%)', 'hsl(340,70%,55%)', 'hsl(38,90%,55%)'];

const Dashboard = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [scores, setScores] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data } = await supabase
        .from('game_scores')
        .select('*')
        .eq('user_id', user.id)
        .order('played_at', { ascending: true });
      setScores(data || []);
      setLoading(false);
    };
    fetchData();
  }, [user]);

  const memoryScores = scores.filter(s => s.game_type === 'memory');
  const wordScores = scores.filter(s => s.game_type === 'word');
  const attentionScores = scores.filter(s => s.game_type === 'attention');
  const spotScores = scores.filter(s => s.game_type === 'spot');

  const lineData = memoryScores.map((s, i) => ({ name: `#${i + 1}`, score: s.score }));
  const barData = wordScores.map((s, i) => ({ name: `#${i + 1}`, score: s.score }));

  const attentionAccuracy = attentionScores.length > 0
    ? attentionScores.reduce((sum, s) => sum + ((s.details as any)?.accuracy || 0), 0) / attentionScores.length
    : 0;
  const pieData = [
    { name: 'Accurate', value: Math.round(attentionAccuracy) },
    { name: 'Missed', value: 100 - Math.round(attentionAccuracy) },
  ];

  const totalGames = scores.length;
  const avgScore = totalGames > 0 ? Math.round(scores.reduce((s, g) => s + g.score, 0) / totalGames) : 0;

  const badges = [];
  if (totalGames >= 1) badges.push({ icon: Star, label: 'First Game', color: COLORS[0] });
  if (totalGames >= 10) badges.push({ icon: Trophy, label: '10 Games', color: COLORS[1] });
  if (memoryScores.some(s => s.score >= 100)) badges.push({ icon: Brain, label: 'Memory Master', color: COLORS[2] });
  if (wordScores.some(s => s.score >= 90)) badges.push({ icon: BookOpen, label: 'Word Wizard', color: COLORS[3] });

  const motivations = [
    "Keep going! Every game strengthens your mind 💪",
    "Great progress! Your brain thanks you 🧠",
    "You're building healthier habits every day ✨",
    "Consistency is key — you're doing amazing! 🌟",
  ];
  const motivation = motivations[Math.floor(Math.random() * motivations.length)];

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl font-heading font-bold text-foreground mb-2">{t('dashboard')}</h1>
        <p className="text-muted-foreground mb-8">{motivation}</p>

        {/* Stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          {[
            { label: t('totalGames'), value: totalGames, icon: Target, color: COLORS[0] },
            { label: 'Avg Score', value: avgScore, icon: Star, color: COLORS[1] },
            { label: t('streak'), value: '—', icon: Flame, color: COLORS[2] },
            { label: t('badges'), value: badges.length, icon: Trophy, color: COLORS[3] },
          ].map((stat, i) => (
            <div key={i} className="bg-card rounded-xl border border-border p-4 shadow-card animate-fade-in" style={{ animationDelay: `${i * 100}ms` }}>
              <div className="flex items-center gap-2 mb-2">
                <stat.icon className="w-4 h-4" style={{ color: stat.color }} />
                <span className="text-xs text-muted-foreground">{stat.label}</span>
              </div>
              <p className="text-2xl font-heading font-bold text-foreground">{stat.value}</p>
            </div>
          ))}
        </div>

        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading...</div>
        ) : scores.length === 0 ? (
          <div className="text-center py-12 bg-card rounded-2xl border border-border shadow-card">
            <Brain className="w-12 h-12 text-primary mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium text-foreground">No games played yet</p>
            <p className="text-muted-foreground text-sm">Play some games to see your progress here!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Memory line chart */}
            {lineData.length > 0 && (
              <div className="bg-card rounded-xl border border-border p-5 shadow-card">
                <h3 className="font-heading font-semibold text-foreground mb-4">{t('memoryRecall')} Trends</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={lineData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(200,20%,90%)" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Line type="monotone" dataKey="score" stroke={COLORS[0]} strokeWidth={2} dot={{ fill: COLORS[0] }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Word bar chart */}
            {barData.length > 0 && (
              <div className="bg-card rounded-xl border border-border p-5 shadow-card">
                <h3 className="font-heading font-semibold text-foreground mb-4">{t('wordRecall')} Scores</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={barData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(200,20%,90%)" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Bar dataKey="score" fill={COLORS[1]} radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Attention pie chart */}
            {attentionScores.length > 0 && (
              <div className="bg-card rounded-xl border border-border p-5 shadow-card">
                <h3 className="font-heading font-semibold text-foreground mb-4">{t('attentionFocus')} Accuracy</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={5} dataKey="value">
                      {pieData.map((_, i) => (
                        <Cell key={i} fill={i === 0 ? COLORS[2] : 'hsl(200,20%,90%)'} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <p className="text-center text-sm text-muted-foreground">{Math.round(attentionAccuracy)}% avg accuracy</p>
              </div>
            )}

            {/* Spot the difference progress */}
            {spotScores.length > 0 && (
              <div className="bg-card rounded-xl border border-border p-5 shadow-card">
                <h3 className="font-heading font-semibold text-foreground mb-4">{t('spotDifference')} Progress</h3>
                <div className="space-y-3">
                  {spotScores.slice(-5).map((s, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <Eye className="w-4 h-4 text-[hsl(38,90%,55%)]" />
                      <div className="flex-1 bg-muted rounded-full h-3">
                        <div className="h-3 rounded-full bg-[hsl(38,90%,55%)]" style={{ width: `${Math.min(100, s.score)}%` }} />
                      </div>
                      <span className="text-sm font-medium text-foreground">{s.score}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Badges */}
        {badges.length > 0 && (
          <div className="mt-8">
            <h3 className="font-heading font-semibold text-foreground mb-4">{t('badges')}</h3>
            <div className="flex flex-wrap gap-3">
              {badges.map((badge, i) => (
                <div key={i} className="flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-full shadow-card">
                  <badge.icon className="w-4 h-4" style={{ color: badge.color }} />
                  <span className="text-sm font-medium text-foreground">{badge.label}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default Dashboard;
