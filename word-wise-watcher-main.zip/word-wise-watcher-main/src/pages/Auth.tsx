import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Brain, Heart, Activity } from 'lucide-react';
import { toast } from 'sonner';

const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const { t, language, setLanguage } = useLanguage();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    username: '',
    email: '',
    password: '',
    age: '',
    gender: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({
          email: form.email,
          password: form.password,
        });
        if (error) throw error;
        navigate('/games');
      } else {
        const { error } = await supabase.auth.signUp({
          email: form.email,
          password: form.password,
          options: {
            data: {
              username: form.username,
              preferred_language: language,
            },
            emailRedirectTo: window.location.origin,
          },
        });
        if (error) throw error;
        toast.success('Account created! Check your email to confirm.');
      }
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Animated gradient background */}
      <div className="absolute inset-0 healthcare-gradient animate-gradient-shift opacity-90" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-transparent to-transparent" />

      {/* Floating decorative elements */}
      <div className="absolute top-20 left-20 animate-float opacity-20">
        <Brain className="w-16 h-16 text-primary-foreground" />
      </div>
      <div className="absolute bottom-32 right-20 animate-float opacity-20" style={{ animationDelay: '1s' }}>
        <Heart className="w-12 h-12 text-primary-foreground" />
      </div>
      <div className="absolute top-40 right-40 animate-float opacity-20" style={{ animationDelay: '2s' }}>
        <Activity className="w-14 h-14 text-primary-foreground" />
      </div>

      {/* Auth card */}
      <div className="relative z-10 w-full max-w-md mx-4 animate-scale-in">
        <div className="bg-card/95 backdrop-blur-xl rounded-2xl shadow-elevated p-8 border border-primary/10">
          {/* Logo area */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 healthcare-gradient rounded-2xl flex items-center justify-center mx-auto mb-4 animate-pulse-glow">
              <Brain className="w-8 h-8 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-heading font-bold text-foreground">{t('cognitiveHealth')}</h1>
            <p className="text-muted-foreground text-sm mt-1">{t('tagline')}</p>
          </div>

          {/* Language selector */}
          <div className="flex justify-center gap-2 mb-6">
            {(['en', 'hi', 'or'] as const).map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`px-3 py-1.5 text-xs font-medium rounded-full transition-all ${
                  language === lang
                    ? 'bg-primary text-primary-foreground glow-primary'
                    : 'bg-muted text-muted-foreground hover:bg-accent'
                }`}
              >
                {lang === 'en' ? 'English' : lang === 'hi' ? 'हिन्दी' : 'ଓଡ଼ିଆ'}
              </button>
            ))}
          </div>

          <h2 className="text-lg font-heading font-semibold text-center mb-6 text-foreground">
            {isLogin ? t('welcomeBack') : t('createAccount')}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div className="relative">
                <Input
                  name="username"
                  placeholder={t('username')}
                  value={form.username}
                  onChange={handleChange}
                  required={!isLogin}
                  className="bg-muted/50 border-border focus:border-primary transition-all"
                />
              </div>
            )}

            <Input
              name="email"
              type="email"
              placeholder={t('email')}
              value={form.email}
              onChange={handleChange}
              required
              className="bg-muted/50 border-border focus:border-primary transition-all"
            />

            <Input
              name="password"
              type="password"
              placeholder={t('password')}
              value={form.password}
              onChange={handleChange}
              required
              minLength={6}
              className="bg-muted/50 border-border focus:border-primary transition-all"
            />

            {!isLogin && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <Input
                    name="age"
                    type="number"
                    placeholder={t('age')}
                    value={form.age}
                    onChange={handleChange}
                    min={1}
                    max={120}
                    className="bg-muted/50 border-border focus:border-primary transition-all"
                  />
                  <select
                    name="gender"
                    value={form.gender}
                    onChange={handleChange}
                    className="flex h-10 w-full rounded-md border border-border bg-muted/50 px-3 py-2 text-sm text-foreground focus:border-primary transition-all outline-none"
                  >
                    <option value="">{t('gender')}</option>
                    <option value="male">{t('male')}</option>
                    <option value="female">{t('female')}</option>
                    <option value="other">{t('other')}</option>
                  </select>
                </div>
              </>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full healthcare-gradient text-primary-foreground font-semibold h-11 rounded-xl animate-pulse-glow hover:opacity-90 transition-opacity"
            >
              {loading ? '...' : isLogin ? t('login') : t('signup')}
            </Button>
          </form>

          <p className="text-center text-sm text-muted-foreground mt-6">
            {isLogin ? t('noAccount') : t('haveAccount')}{' '}
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-primary font-semibold hover:underline"
            >
              {isLogin ? t('signup') : t('login')}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Auth;
