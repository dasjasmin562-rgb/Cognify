import React, { useState, useEffect, useCallback } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const MemoryGame = () => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [phase, setPhase] = useState<'start' | 'show' | 'input' | 'result'>('start');
  const [sequence, setSequence] = useState<number[]>([]);
  const [userInput, setUserInput] = useState<number[]>([]);
  const [level, setLevel] = useState(3);
  const [score, setScore] = useState(0);
  const [totalRounds, setTotalRounds] = useState(0);

  const generateSequence = useCallback(() => {
    const seq = Array.from({ length: level }, () => Math.floor(Math.random() * 9) + 1);
    setSequence(seq);
    setUserInput([]);
    setPhase('show');
    setTimeout(() => setPhase('input'), 2000 + level * 500);
  }, [level]);

  const handleNumberClick = (num: number) => {
    if (phase !== 'input') return;
    const newInput = [...userInput, num];
    setUserInput(newInput);

    if (newInput.length === sequence.length) {
      const correct = newInput.every((n, i) => n === sequence[i]);
      if (correct) {
        setScore(s => s + level * 10);
        setLevel(l => l + 1);
        toast.success(t('correct'));
        setTimeout(generateSequence, 1000);
      } else {
        setTotalRounds(r => r + 1);
        setPhase('result');
      }
    }
  };

  const saveScore = async () => {
    if (!user) return;
    await supabase.from('game_scores').insert({
      user_id: user.id,
      game_type: 'memory',
      score,
      details: { level_reached: level, rounds: totalRounds + 1 },
    });
  };

  useEffect(() => {
    if (phase === 'result') saveScore();
  }, [phase]);

  if (phase === 'start') {
    return (
      <div className="text-center py-12">
        <div className="w-20 h-20 bg-gradient-to-br from-[hsl(199,89%,48%)] to-[hsl(199,89%,38%)] rounded-2xl flex items-center justify-center mx-auto mb-6">
          <span className="text-3xl">🧠</span>
        </div>
        <h2 className="text-2xl font-heading font-bold text-foreground mb-2">{t('memoryRecall')}</h2>
        <p className="text-muted-foreground mb-6">{t('memoryDesc')}</p>
        <Button onClick={generateSequence} className="healthcare-gradient text-primary-foreground px-8">{t('startGame')}</Button>
      </div>
    );
  }

  if (phase === 'result') {
    return (
      <div className="text-center py-12 animate-fade-in">
        <h2 className="text-2xl font-heading font-bold text-foreground mb-2">{t('gameOver')}</h2>
        <p className="text-4xl font-bold text-primary mb-6">{score}</p>
        <p className="text-muted-foreground mb-6">Level reached: {level - 1}</p>
        <Button onClick={() => { setPhase('start'); setScore(0); setLevel(3); setTotalRounds(0); }} className="healthcare-gradient text-primary-foreground">
          {t('playAgain')}
        </Button>
      </div>
    );
  }

  return (
    <div className="text-center py-8 animate-fade-in">
      <div className="mb-4">
        <span className="text-sm font-medium text-muted-foreground">{t('score')}: {score}</span>
        <span className="mx-4 text-sm text-muted-foreground">Level {level - 2}</span>
      </div>

      {phase === 'show' && (
        <div className="my-8">
          <p className="text-lg font-medium text-foreground mb-4">{t('memorize')}</p>
          <div className="flex justify-center gap-3 flex-wrap">
            {sequence.map((num, i) => (
              <div key={i} className="w-14 h-14 bg-primary text-primary-foreground rounded-xl flex items-center justify-center text-xl font-bold animate-scale-in" style={{ animationDelay: `${i * 150}ms` }}>
                {num}
              </div>
            ))}
          </div>
        </div>
      )}

      {phase === 'input' && (
        <div className="my-8">
          <p className="text-lg font-medium text-foreground mb-4">{t('enterSequence')}</p>
          <div className="flex justify-center gap-2 mb-6 min-h-[56px]">
            {userInput.map((num, i) => (
              <div key={i} className="w-12 h-12 bg-secondary text-secondary-foreground rounded-xl flex items-center justify-center text-lg font-bold">{num}</div>
            ))}
            {Array.from({ length: sequence.length - userInput.length }).map((_, i) => (
              <div key={`e-${i}`} className="w-12 h-12 border-2 border-dashed border-border rounded-xl" />
            ))}
          </div>
          <div className="grid grid-cols-3 gap-2 max-w-[200px] mx-auto">
            {[1,2,3,4,5,6,7,8,9].map(num => (
              <button key={num} onClick={() => handleNumberClick(num)}
                className="w-14 h-14 bg-card border border-border rounded-xl text-lg font-semibold text-foreground hover:bg-primary hover:text-primary-foreground transition-colors shadow-card">
                {num}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default MemoryGame;
