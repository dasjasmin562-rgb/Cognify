import React, { useState, useEffect, useCallback } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';

// Generate a grid of colored circles with some differences
const generateGrid = () => {
  const colors = ['#3b82f6', '#22c55e', '#ef4444', '#f59e0b', '#8b5cf6', '#ec4899'];
  const size = 5;
  const base: string[][] = [];
  for (let r = 0; r < size; r++) {
    const row: string[] = [];
    for (let c = 0; c < size; c++) {
      row.push(colors[Math.floor(Math.random() * colors.length)]);
    }
    base.push(row);
  }

  // Create modified version with 3-5 differences
  const modified = base.map(r => [...r]);
  const diffCount = 3 + Math.floor(Math.random() * 3);
  const diffs: [number, number][] = [];

  while (diffs.length < diffCount) {
    const r = Math.floor(Math.random() * size);
    const c = Math.floor(Math.random() * size);
    if (!diffs.some(([dr, dc]) => dr === r && dc === c)) {
      let newColor = colors[Math.floor(Math.random() * colors.length)];
      while (newColor === base[r][c]) newColor = colors[Math.floor(Math.random() * colors.length)];
      modified[r][c] = newColor;
      diffs.push([r, c]);
    }
  }

  return { base, modified, diffs };
};

const SpotDifferenceGame = () => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [phase, setPhase] = useState<'start' | 'play' | 'result'>('start');
  const [grids, setGrids] = useState<{ base: string[][]; modified: string[][]; diffs: [number, number][] }>({ base: [], modified: [], diffs: [] });
  const [found, setFound] = useState<[number, number][]>([]);
  const [timeLeft, setTimeLeft] = useState(30);
  const [score, setScore] = useState(0);

  const startGame = () => {
    setGrids(generateGrid());
    setFound([]);
    setTimeLeft(30);
    setScore(0);
    setPhase('play');
  };

  useEffect(() => {
    if (phase !== 'play') return;
    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setPhase('result');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [phase]);

  useEffect(() => {
    if (found.length === grids.diffs.length && grids.diffs.length > 0) {
      setPhase('result');
    }
  }, [found, grids.diffs.length]);

  useEffect(() => {
    if (phase === 'result' && user) {
      const finalScore = found.length * 20 + timeLeft * 2;
      setScore(finalScore);
      supabase.from('game_scores').insert({
        user_id: user.id,
        game_type: 'spot',
        score: finalScore,
        details: { found: found.length, total: grids.diffs.length, time_remaining: timeLeft },
      });
    }
  }, [phase]);

  const handleCellClick = (r: number, c: number) => {
    if (phase !== 'play') return;
    if (grids.diffs.some(([dr, dc]) => dr === r && dc === c) && !found.some(([fr, fc]) => fr === r && fc === c)) {
      setFound([...found, [r, c]]);
    }
  };

  const renderGrid = (grid: string[][], isModified: boolean) => (
    <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${grid[0]?.length || 5}, 1fr)` }}>
      {grid.map((row, r) =>
        row.map((color, c) => {
          const isFound = found.some(([fr, fc]) => fr === r && fc === c);
          return (
            <div
              key={`${r}-${c}`}
              onClick={() => isModified && handleCellClick(r, c)}
              className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg transition-all cursor-pointer ${isFound ? 'ring-2 ring-secondary scale-110' : 'hover:scale-105'}`}
              style={{ backgroundColor: color }}
            />
          );
        })
      )}
    </div>
  );

  if (phase === 'start') {
    return (
      <div className="text-center py-12">
        <div className="w-20 h-20 bg-gradient-to-br from-[hsl(38,90%,55%)] to-[hsl(38,90%,45%)] rounded-2xl flex items-center justify-center mx-auto mb-6">
          <span className="text-3xl">👁️</span>
        </div>
        <h2 className="text-2xl font-heading font-bold text-foreground mb-2">{t('spotDifference')}</h2>
        <p className="text-muted-foreground mb-6">{t('spotDesc')}</p>
        <Button onClick={startGame} className="bg-[hsl(38,90%,55%)] hover:bg-[hsl(38,90%,45%)] text-primary-foreground px-8">{t('startGame')}</Button>
      </div>
    );
  }

  if (phase === 'result') {
    return (
      <div className="text-center py-12 animate-fade-in">
        <h2 className="text-2xl font-heading font-bold text-foreground mb-2">{t('gameOver')}</h2>
        <p className="text-4xl font-bold text-[hsl(38,90%,55%)] mb-2">{score}</p>
        <p className="text-muted-foreground mb-6">{found.length}/{grids.diffs.length} {t('differencesFound')}</p>
        <Button onClick={startGame} className="bg-[hsl(38,90%,55%)] hover:bg-[hsl(38,90%,45%)] text-primary-foreground">{t('playAgain')}</Button>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-4">
        <span className="text-sm font-medium text-foreground">{found.length}/{grids.diffs.length} {t('differencesFound')}</span>
        <span className="text-sm font-medium text-muted-foreground">{t('timeLeft')}: {timeLeft}s</span>
      </div>
      <p className="text-center text-sm text-muted-foreground mb-4">{t('findDifferences')} (Click differences in the right grid)</p>
      <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
        <div>
          <p className="text-xs text-muted-foreground mb-2 text-center">Original</p>
          {renderGrid(grids.base, false)}
        </div>
        <div>
          <p className="text-xs text-muted-foreground mb-2 text-center">Modified</p>
          {renderGrid(grids.modified, true)}
        </div>
      </div>
    </div>
  );
};

export default SpotDifferenceGame;
