import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';

interface Shape {
  id: number;
  type: 'circle' | 'square' | 'triangle';
  x: number;
  y: number;
  color: string;
  isTarget: boolean;
}

const AttentionGame = () => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [phase, setPhase] = useState<'start' | 'play' | 'result'>('start');
  const [targetShape, setTargetShape] = useState<'circle' | 'square' | 'triangle'>('circle');
  const [shapes, setShapes] = useState<Shape[]>([]);
  const [score, setScore] = useState(0);
  const [misses, setMisses] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [hits, setHits] = useState(0);
  const [totalTargets, setTotalTargets] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const shapeTypes: ('circle' | 'square' | 'triangle')[] = ['circle', 'square', 'triangle'];
  const colors = ['hsl(199,89%,48%)', 'hsl(152,60%,45%)', 'hsl(340,70%,55%)', 'hsl(38,90%,55%)'];

  const generateShapes = useCallback(() => {
    const target = shapeTypes[Math.floor(Math.random() * 3)];
    setTargetShape(target);

    const newShapes: Shape[] = [];
    const count = 8 + Math.floor(Math.random() * 5);
    let targetsCount = 0;

    for (let i = 0; i < count; i++) {
      const type = Math.random() < 0.3 ? target : shapeTypes[Math.floor(Math.random() * 3)];
      const isTarget = type === target;
      if (isTarget) targetsCount++;
      newShapes.push({
        id: i,
        type,
        x: 10 + Math.random() * 75,
        y: 10 + Math.random() * 75,
        color: colors[Math.floor(Math.random() * colors.length)],
        isTarget,
      });
    }
    if (targetsCount === 0) {
      newShapes[0].type = target;
      newShapes[0].isTarget = true;
      targetsCount = 1;
    }
    setTotalTargets(prev => prev + targetsCount);
    setShapes(newShapes);
  }, []);

  const startGame = () => {
    setScore(0); setMisses(0); setHits(0); setTotalTargets(0); setTimeLeft(30);
    setPhase('play');
    generateShapes();
  };

  useEffect(() => {
    if (phase !== 'play') return;
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          setPhase('result');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [phase]);

  useEffect(() => {
    if (phase === 'play') {
      const interval = setInterval(generateShapes, 3000);
      return () => clearInterval(interval);
    }
  }, [phase, generateShapes]);

  useEffect(() => {
    if (phase === 'result' && user) {
      supabase.from('game_scores').insert({
        user_id: user.id,
        game_type: 'attention',
        score,
        details: { hits, misses, total_targets: totalTargets, accuracy: totalTargets > 0 ? Math.round((hits / totalTargets) * 100) : 0 },
      });
    }
  }, [phase]);

  const handleClick = (shape: Shape) => {
    if (shape.isTarget) {
      setScore(s => s + 10);
      setHits(h => h + 1);
      setShapes(prev => prev.filter(s => s.id !== shape.id));
    } else {
      setMisses(m => m + 1);
      setScore(s => Math.max(0, s - 5));
    }
  };

  const renderShape = (shape: Shape) => {
    const common = {
      position: 'absolute' as const,
      left: `${shape.x}%`,
      top: `${shape.y}%`,
      cursor: 'pointer',
      transition: 'transform 0.1s',
    };

    if (shape.type === 'circle') {
      return <div key={shape.id} onClick={() => handleClick(shape)} style={{ ...common, width: 40, height: 40, borderRadius: '50%', backgroundColor: shape.color }} className="hover:scale-125" />;
    }
    if (shape.type === 'square') {
      return <div key={shape.id} onClick={() => handleClick(shape)} style={{ ...common, width: 36, height: 36, borderRadius: 4, backgroundColor: shape.color }} className="hover:scale-125" />;
    }
    // triangle
    return <div key={shape.id} onClick={() => handleClick(shape)} style={{ ...common, width: 0, height: 0, borderLeft: '20px solid transparent', borderRight: '20px solid transparent', borderBottom: `36px solid ${shape.color}` }} className="hover:scale-125" />;
  };

  if (phase === 'start') {
    return (
      <div className="text-center py-12">
        <div className="w-20 h-20 bg-gradient-to-br from-[hsl(340,70%,55%)] to-[hsl(340,70%,45%)] rounded-2xl flex items-center justify-center mx-auto mb-6">
          <span className="text-3xl">🎯</span>
        </div>
        <h2 className="text-2xl font-heading font-bold text-foreground mb-2">{t('attentionFocus')}</h2>
        <p className="text-muted-foreground mb-6">{t('attentionDesc')}</p>
        <Button onClick={startGame} className="bg-[hsl(340,70%,55%)] hover:bg-[hsl(340,70%,45%)] text-primary-foreground px-8">{t('startGame')}</Button>
      </div>
    );
  }

  if (phase === 'result') {
    const accuracy = totalTargets > 0 ? Math.round((hits / totalTargets) * 100) : 0;
    return (
      <div className="text-center py-12 animate-fade-in">
        <h2 className="text-2xl font-heading font-bold text-foreground mb-2">{t('gameOver')}</h2>
        <p className="text-4xl font-bold text-[hsl(340,70%,55%)] mb-2">{score}</p>
        <p className="text-muted-foreground mb-6">Accuracy: {accuracy}% | Hits: {hits} | Misses: {misses}</p>
        <Button onClick={startGame} className="bg-[hsl(340,70%,55%)] hover:bg-[hsl(340,70%,45%)] text-primary-foreground">{t('playAgain')}</Button>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="flex justify-between items-center mb-4">
        <span className="text-sm font-medium text-foreground">{t('score')}: {score}</span>
        <span className="text-sm font-medium px-3 py-1 bg-primary/10 text-primary rounded-full">
          {t('clickTarget')} {t(targetShape)} ⬤
        </span>
        <span className="text-sm font-medium text-muted-foreground">{t('timeLeft')}: {timeLeft}s</span>
      </div>
      <div className="relative bg-muted/50 border border-border rounded-2xl" style={{ height: 400 }}>
        {shapes.map(renderShape)}
      </div>
    </div>
  );
};

export default AttentionGame;
