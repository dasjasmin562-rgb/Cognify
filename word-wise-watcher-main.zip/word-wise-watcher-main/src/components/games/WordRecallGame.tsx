import React, { useState, useEffect, useCallback } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const wordSets = [
  ['apple', 'river', 'cloud', 'house', 'music', 'green', 'table', 'heart'],
  ['ocean', 'light', 'train', 'smile', 'stone', 'dream', 'clock', 'plant'],
  ['bread', 'space', 'earth', 'dance', 'paper', 'brush', 'flame', 'frost'],
];

const WordRecallGame = () => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [phase, setPhase] = useState<'start' | 'show' | 'input' | 'result'>('start');
  const [words, setWords] = useState<string[]>([]);
  const [currentInput, setCurrentInput] = useState('');
  const [recalled, setRecalled] = useState<string[]>([]);
  const [score, setScore] = useState(0);

  const startGame = () => {
    const set = wordSets[Math.floor(Math.random() * wordSets.length)];
    setWords(set);
    setRecalled([]);
    setCurrentInput('');
    setPhase('show');
    setTimeout(() => setPhase('input'), 5000);
  };

  const addWord = () => {
    const word = currentInput.trim().toLowerCase();
    if (word && !recalled.includes(word)) {
      setRecalled([...recalled, word]);
    }
    setCurrentInput('');
  };

  const finishGame = async () => {
    const correct = recalled.filter(w => words.includes(w)).length;
    const s = correct * 15;
    setScore(s);
    setPhase('result');
    if (user) {
      await supabase.from('game_scores').insert({
        user_id: user.id,
        game_type: 'word',
        score: s,
        details: { total_words: words.length, recalled: correct, words_recalled: recalled },
      });
    }
  };

  if (phase === 'start') {
    return (
      <div className="text-center py-12">
        <div className="w-20 h-20 bg-gradient-to-br from-[hsl(262,60%,55%)] to-[hsl(262,60%,45%)] rounded-2xl flex items-center justify-center mx-auto mb-6">
          <span className="text-3xl">📝</span>
        </div>
        <h2 className="text-2xl font-heading font-bold text-foreground mb-2">{t('wordRecall')}</h2>
        <p className="text-muted-foreground mb-6">{t('wordDesc')}</p>
        <Button onClick={startGame} className="bg-[hsl(262,60%,55%)] hover:bg-[hsl(262,60%,45%)] text-primary-foreground px-8">{t('startGame')}</Button>
      </div>
    );
  }

  if (phase === 'show') {
    return (
      <div className="text-center py-8 animate-fade-in">
        <p className="text-lg font-medium text-foreground mb-6">{t('memorizeWords')}</p>
        <div className="flex flex-wrap justify-center gap-3 max-w-md mx-auto">
          {words.map((word, i) => (
            <span key={i} className="px-4 py-2 bg-[hsl(262,60%,55%)/0.15] text-foreground rounded-full text-sm font-medium animate-scale-in" style={{ animationDelay: `${i * 100}ms` }}>
              {word}
            </span>
          ))}
        </div>
        <p className="text-muted-foreground text-sm mt-4">5s...</p>
      </div>
    );
  }

  if (phase === 'result') {
    const correct = recalled.filter(w => words.includes(w));
    return (
      <div className="text-center py-12 animate-fade-in">
        <h2 className="text-2xl font-heading font-bold text-foreground mb-2">{t('gameOver')}</h2>
        <p className="text-4xl font-bold text-[hsl(262,60%,55%)] mb-2">{score}</p>
        <p className="text-muted-foreground mb-4">{correct.length}/{words.length} words correct</p>
        <div className="flex flex-wrap justify-center gap-2 mb-6">
          {words.map((w, i) => (
            <span key={i} className={`px-3 py-1 rounded-full text-sm font-medium ${recalled.includes(w) ? 'bg-secondary/20 text-secondary' : 'bg-destructive/10 text-destructive'}`}>{w}</span>
          ))}
        </div>
        <Button onClick={() => { setPhase('start'); setScore(0); }} className="bg-[hsl(262,60%,55%)] hover:bg-[hsl(262,60%,45%)] text-primary-foreground">{t('playAgain')}</Button>
      </div>
    );
  }

  return (
    <div className="text-center py-8 animate-fade-in">
      <p className="text-lg font-medium text-foreground mb-4">{t('typeWords')}</p>
      <div className="flex gap-2 max-w-sm mx-auto mb-4">
        <Input
          value={currentInput}
          onChange={e => setCurrentInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && addWord()}
          placeholder="Type a word..."
          className="bg-muted/50"
        />
        <Button onClick={addWord} variant="outline">+</Button>
      </div>
      <div className="flex flex-wrap justify-center gap-2 mb-6 min-h-[40px]">
        {recalled.map((w, i) => (
          <span key={i} className="px-3 py-1 bg-accent text-accent-foreground rounded-full text-sm">{w}</span>
        ))}
      </div>
      <Button onClick={finishGame} className="bg-[hsl(262,60%,55%)] hover:bg-[hsl(262,60%,45%)] text-primary-foreground">{t('submit')}</Button>
    </div>
  );
};

export default WordRecallGame;
